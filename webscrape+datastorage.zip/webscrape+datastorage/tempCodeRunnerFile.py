     data["product_name"].append(title) 
    #             data["price"].append(price)
    #             data["description"].append(description)
    #             data["reviews"].append(reviews)
    #             data["rating"].append(rating)
    #             data["image"].append(imgsrc)
                
    # return data